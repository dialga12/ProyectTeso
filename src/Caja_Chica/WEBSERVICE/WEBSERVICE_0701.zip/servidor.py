from Beta import *
from flask import Flask, request, make_response
import barrister

# Implementation of the Alpha interface in the IDL
class Alpha(object):

   def Alpha(self, p_cParStr):
       print '111'
       print p_cParStr
       if p_cParStr == None or p_cParStr.strip() == '':
          return '<DATA><ERROR>ERROR EN PARAMETRO</ERROR></DATA>'
       lo = Beta()
       llOk = lo.Dispatch(p_cParStr)
       if llOk:
          return lo.pcData
       else:
          return lo.pcError

contract = barrister.contract_from_file("Alpha.json")
server   = barrister.Server(contract)
server.add_handler("Alpha", Alpha())

app = Flask(__name__)

@app.route("/Alpha", methods=["POST"])
def get_Alpha():
    resp_data = server.call_json(request.data)
    resp = make_response(resp_data)
    resp.headers['Content-Type'] = 'application/json'
    return resp

app.run(host="127.0.0.1", port=7667)
#app.run(host="10.0.159.15", port=7667)


